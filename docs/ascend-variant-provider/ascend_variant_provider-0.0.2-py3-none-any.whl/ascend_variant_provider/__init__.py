"""
WheelNext Variant Provider for Ascend"
"""
__version__ = "0.0.2"
__description__ = "A WheelNext Variant Provider for Ascend"
__all__ = ["__version__", "__description__"]
